import numpy as np


def funExp(row):
    row = np.exp(float(row))
    return row
