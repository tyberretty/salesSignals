

def xrange(x):
    return iter(range(x))
